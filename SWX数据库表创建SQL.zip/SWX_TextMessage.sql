USE [sqlsimpob2bmssql]
GO

/****** Object:  Table [simpob2bmssql].[SWX_TextMessage]    Script Date: 12/05/2014 23:07:09 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [simpob2bmssql].[SWX_TextMessage](
	[Id] [int] NOT NULL,
	[OrgId] [nvarchar](50) NULL,
	[Status] [bit] NULL,
	[CreateTime] [datetime] NULL,
 CONSTRAINT [PK_SWX_TextMessage] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

