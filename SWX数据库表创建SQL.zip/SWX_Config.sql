USE [sqlsimpob2bmssql]
GO

/****** Object:  Table [simpob2bmssql].[SWX_Config]    Script Date: 12/05/2014 23:06:28 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [simpob2bmssql].[SWX_Config](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[OrgID] [nvarchar](50) NULL,
	[Token] [nvarchar](50) NULL,
	[AppID] [nvarchar](200) NULL,
	[EncodingAESKey] [nvarchar](200) NULL,
	[UserName] [nvarchar](50) NULL,
	[Password] [nvarchar](100) NULL,
	[access_token] [nvarchar](1024) NULL,
	[AppSecret] [nvarchar](200) NULL,
	[Status] [int] NULL,
 CONSTRAINT [SWX_Config_PK] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

