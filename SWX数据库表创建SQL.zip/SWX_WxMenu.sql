USE [sqlsimpob2bmssql]
GO

/****** Object:  Table [simpob2bmssql].[SWX_WxMenu]    Script Date: 12/05/2014 23:07:22 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [simpob2bmssql].[SWX_WxMenu](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Code] [nvarchar](10) NOT NULL,
	[Name] [nvarchar](20) NOT NULL,
	[Type] [nvarchar](10) NULL,
	[MenuKey] [nvarchar](50) NULL,
	[Url] [nvarchar](1000) NULL,
	[OrgID] [nvarchar](50) NULL,
 CONSTRAINT [SWX_WxMenu_PK] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

