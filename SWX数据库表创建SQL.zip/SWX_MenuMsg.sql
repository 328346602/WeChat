USE [sqlsimpob2bmssql]
GO

/****** Object:  Table [simpob2bmssql].[SWX_MenuMsg]    Script Date: 12/05/2014 23:06:57 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [simpob2bmssql].[SWX_MenuMsg](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[MenuKey] [nvarchar](50) NOT NULL,
	[Title] [nvarchar](4000) NULL,
	[Description] [nvarchar](4000) NULL,
	[PicUrl] [nvarchar](1000) NULL,
	[Url] [nvarchar](1000) NULL,
	[Sort] [int] NOT NULL,
	[OrgID] [nvarchar](50) NULL,
 CONSTRAINT [SWX_MenuMsg_PK] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

